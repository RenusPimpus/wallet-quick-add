# Szybki wydatek dla Wallet

Pierwsze MVP aplikacji Android dodającej wydatek do **Wallet by BudgetBakers** przez oficjalne REST API.

## Co działa

- aplikacja pojawia się w systemowym menu **Udostępnij** dla tekstu;
- pojawia się jako akcja **Przetwórz tekst** po zaznaczeniu kwoty;
- rozpoznaje m.in. `12,50 zł`, `1 234,56 PLN`, `8.99 USD`;
- przed zapisem zawsze pokazuje ekran potwierdzenia;
- pobiera aktywne konta i kategorie z Wallet;
- pamięta ostatnio używane konto i kategorię;
- tworzy wydatek przez `POST /wallet/v1/api/records`;
- szyfruje token lokalnie kluczem z Android Keystore;
- nie zawiera analityki, reklam ani pośredniego serwera.

## Uruchomienie

1. Otwórz katalog projektu w aktualnym Android Studio.
2. Poczekaj na synchronizację Gradle i uruchom aplikację na telefonie z Androidem 8 lub nowszym.
3. W webowej wersji Wallet otwórz **Settings / Ustawienia** i wygeneruj osobisty token REST API.
4. Wklej token w aplikacji i wybierz **Połącz i pobierz ustawienia**.
5. Zaznacz kwotę w dowolnej aplikacji i użyj **Przetwórz tekst → Szybki wydatek**, albo udostępnij tekst do aplikacji.

Nie umieszczaj tokenu w `local.properties`, repozytorium ani zrzutach ekranu. Token daje dostęp do danych finansowych.

## Architektura MVP

- `MainActivity` — odbiera `ACTION_SEND` i `ACTION_PROCESS_TEXT`, renderuje Compose UI;
- `MainViewModel` — stan formularza i operacje w tle;
- `WalletApiClient` — bezpośrednia komunikacja HTTPS z oficjalnym API;
- `SecureTokenStore` — AES/GCM, klucz sprzężony z Android Keystore;
- `AmountParser` — bezpieczne, jawne parsowanie kwoty z polskim separatorem.

## Znane ograniczenia pierwszej wersji

- lista kategorii jest długa i nie ma jeszcze wyszukiwarki ani ulubionych;
- parser bierze pierwszą pasującą kwotę; ekran potwierdzenia jest celowo obowiązkowy;
- brak kolejki offline — bez internetu wpis nie zostanie zachowany;
- nie ma jeszcze podpisanego APK; podpis debugowy tworzy Android Studio;
- test połączenia wymaga prawdziwego tokenu, którego celowo nie zapisujemy w projekcie.

## Następna sensowna iteracja

1. wyszukiwarka oraz 4–6 przypiętych kategorii;
2. szybkie kafelki kwot/kategorii i skrót na ekranie głównym;
3. lokalna kolejka rekordów z wyraźnym statusem synchronizacji;
4. testy integracyjne na kontrolowanym koncie Wallet;
5. podpisany APK i prosty ekran diagnostyczny bez ujawniania tokenu.

## API

Projekt jest oparty na Wallet REST API 2.0.0:

- baza: `https://rest.budgetbakers.com/wallet`;
- autoryzacja: `Authorization: Bearer <token>`;
- konta: `GET /v1/api/accounts`;
- kategorie: `GET /v1/api/categories`;
- utworzenie rekordu: `POST /v1/api/records`.

API może podczas pierwszej synchronizacji zwrócić HTTP 409; aplikacja pokazuje wtedy komunikat i pozwala odświeżyć dane.
