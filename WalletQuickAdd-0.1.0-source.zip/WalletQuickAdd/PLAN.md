# Plan produktu: Szybki wydatek

## Cel

Skrócić ręczne dodanie wydatku do Wallet z otwierania aplikacji i wypełniania formularza do:

1. zaznaczenia lub udostępnienia kwoty;
2. sprawdzenia kwoty, konta i kategorii;
3. jednego kliknięcia **Zapisz wydatek**.

Nie zakładamy automatycznego zapisu bez potwierdzenia. Tekst z paragonu, SMS-a lub strony może zawierać kilka liczb, a fałszywa oszczędność jednego kliknięcia nie jest warta błędnych danych finansowych.

## MVP 0.1 — wykonane

| Obszar | Zakres |
|---|---|
| Wejście | Android `ACTION_SEND` i `ACTION_PROCESS_TEXT` dla tekstu |
| Kwota | Polski przecinek, kropka, spacje tysięczne, popularne oznaczenia walut |
| Konfiguracja | Osobisty token REST API, konta i kategorie pobierane z Wallet |
| Formularz | Kwota, konto, kategoria, kontrahent, notatka |
| Pamięć | Ostatnio wybrane konto i kategoria |
| Zapis | Oficjalny `POST /v1/api/records`; kwota wydatku wysyłana jako ujemna |
| Bezpieczeństwo | Token szyfrowany AES/GCM kluczem z Android Keystore, wyłączony backup aplikacji |
| Błędy | Osobne komunikaty dla 401, 403, 409, 429 i problemów sieciowych |

## Przepływ danych

```mermaid
flowchart TD
    A["Zaznaczony lub udostępniony tekst"] --> B["Lokalny parser kwoty"]
    B --> C["Ekran potwierdzenia"]
    C --> D["Wallet REST API"]
    D --> E["Nowy rekord wydatku"]
```

Poza połączeniem HTTPS z `rest.budgetbakers.com` aplikacja nie komunikuje się z żadnym serwerem.

## Kryteria odbioru MVP

- po zaznaczeniu `Razem 123,45 zł` aplikacja otwiera formularz z kwotą `123,45`;
- aplikacja nie zapisuje niczego przed naciśnięciem przycisku;
- pierwszy zapis wymaga jawnego wyboru konta i kategorii;
- kolejne uruchomienie zachowuje wybór konta i kategorii;
- błędny token nie ujawnia swojej wartości w komunikacie ani logach;
- API otrzymuje `-123.45`, a nie dodatni przychód;
- brak sieci pozostawia formularz do ponowienia próby;
- HTTP 409 przy pierwszej synchronizacji jest opisany jako stan przejściowy.

## Iteracja 0.2 — po teście na telefonie

- wyszukiwarka kategorii i przypinanie ulubionych;
- sortowanie kont według ostatniego użycia;
- rozpoznawanie kontrahenta z pełnego udostępnionego tekstu;
- przycisk **Zapisz i zamknij** oraz sensowna obsługa przycisku Wstecz;
- test UI na Samsungu Galaxy S25 / One UI 8.5;
- test prawdziwego zapisu na osobnym koncie lub rekordzie przeznaczonym do usunięcia.

## Iteracja 0.3 — dopiero jeśli będzie potrzebna

- kolejka offline z widocznym statusem każdego wpisu;
- reguły „kontrahent → domyślna kategoria”;
- skrót/kafelek szybkich ustawień;
- import tekstu ze schowka po jawnym naciśnięciu **Wklej**;
- podpisany build release i dystrybucja prywatna.

## Ryzyka

1. Wallet może zmienić schemat lub limity API — klient powinien pozostać mały i łatwy do aktualizacji.
2. `ACTION_PROCESS_TEXT` zależy od tego, czy konkretna aplikacja pozwala zaznaczyć tekst i pokazuje akcje systemowe.
3. Aplikacje kalkulatorów i banków mogą blokować kopiowanie lub udostępnianie; tego nie da się uczciwie obejść bez usług dostępności, których w tym projekcie celowo nie używamy.
4. Automatyczne wybieranie kategorii powinno pojawić się dopiero po zebraniu realnych przykładów, nie na podstawie efektownego zgadywania.
