# The app uses only platform JSON APIs; no reflection-based model serialization.
