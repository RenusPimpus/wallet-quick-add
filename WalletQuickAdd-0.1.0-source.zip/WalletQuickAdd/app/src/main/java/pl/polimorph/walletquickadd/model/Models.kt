package pl.polimorph.walletquickadd.model

data class WalletAccount(
    val id: String,
    val name: String,
    val currencyCode: String,
    val isBankSync: Boolean,
)

data class WalletCategory(
    val id: String,
    val name: String,
    val groupName: String,
)

data class WalletConfiguration(
    val accounts: List<WalletAccount>,
    val categories: List<WalletCategory>,
)

data class ExpenseDraft(
    val accountId: String,
    val categoryId: String,
    val amount: Double,
    val counterParty: String,
    val note: String,
    val recordDateIso: String,
)

sealed interface ApiResult<out T> {
    data class Success<T>(val value: T) : ApiResult<T>
    data class Failure(val message: String, val retryAfterSeconds: Int? = null) : ApiResult<Nothing>
}
