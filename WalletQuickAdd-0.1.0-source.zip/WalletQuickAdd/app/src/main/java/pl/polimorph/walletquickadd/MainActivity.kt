package pl.polimorph.walletquickadd

import android.content.Intent
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.viewModels
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import pl.polimorph.walletquickadd.model.WalletAccount
import pl.polimorph.walletquickadd.model.WalletCategory

class MainActivity : ComponentActivity() {
    private val mainViewModel: MainViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        handleTextIntent(intent)
        setContent {
            MaterialTheme {
                QuickExpenseApp(mainViewModel)
            }
        }
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
        handleTextIntent(intent)
    }

    private fun handleTextIntent(intent: Intent) {
        val sharedText = when (intent.action) {
            Intent.ACTION_SEND -> intent.getStringExtra(Intent.EXTRA_TEXT)
            Intent.ACTION_PROCESS_TEXT -> intent.getCharSequenceExtra(Intent.EXTRA_PROCESS_TEXT)?.toString()
            else -> null
        }
        mainViewModel.acceptSharedText(sharedText)
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun QuickExpenseApp(viewModel: MainViewModel) {
    val state by viewModel.state.collectAsState()
    Scaffold(
        topBar = { TopAppBar(title = { Text("Szybki wydatek") }) },
    ) { padding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding),
        ) {
            if (!state.hasToken) {
                TokenSetup(
                    token = state.tokenInput,
                    message = state.message,
                    busy = state.isBusy,
                    onTokenChange = viewModel::updateToken,
                    onConnect = viewModel::saveTokenAndConnect,
                )
            } else {
                ExpenseForm(
                    state = state,
                    onAmountChange = viewModel::updateAmount,
                    onCounterPartyChange = viewModel::updateCounterParty,
                    onNoteChange = viewModel::updateNote,
                    onAccountSelected = viewModel::selectAccount,
                    onCategorySelected = viewModel::selectCategory,
                    onSave = viewModel::saveExpense,
                    onRefresh = viewModel::refreshConfiguration,
                    onReplaceToken = viewModel::replaceToken,
                )
            }
            if (state.isBusy) {
                CircularProgressIndicator(modifier = Modifier.align(Alignment.Center))
            }
        }
    }
}

@Composable
private fun TokenSetup(
    token: String,
    message: String?,
    busy: Boolean,
    onTokenChange: (String) -> Unit,
    onConnect: () -> Unit,
) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(24.dp)
            .verticalScroll(rememberScrollState()),
        verticalArrangement = Arrangement.Center,
    ) {
        Text("Połącz z Wallet", style = MaterialTheme.typography.headlineSmall)
        Spacer(Modifier.height(8.dp))
        Text(
            "W aplikacji webowej Wallet otwórz Ustawienia, wygeneruj osobisty token REST API i wklej go poniżej. Token zostanie zaszyfrowany w tym telefonie.",
            style = MaterialTheme.typography.bodyMedium,
        )
        Spacer(Modifier.height(20.dp))
        OutlinedTextField(
            value = token,
            onValueChange = onTokenChange,
            modifier = Modifier.fillMaxWidth(),
            label = { Text("Token API") },
            visualTransformation = PasswordVisualTransformation(),
            singleLine = true,
        )
        message?.let {
            Spacer(Modifier.height(8.dp))
            Text(it, color = MaterialTheme.colorScheme.error)
        }
        Spacer(Modifier.height(16.dp))
        Button(
            onClick = onConnect,
            enabled = !busy,
            modifier = Modifier.fillMaxWidth(),
        ) { Text("Połącz i pobierz ustawienia") }
    }
}

@Composable
private fun ExpenseForm(
    state: MainUiState,
    onAmountChange: (String) -> Unit,
    onCounterPartyChange: (String) -> Unit,
    onNoteChange: (String) -> Unit,
    onAccountSelected: (String) -> Unit,
    onCategorySelected: (String) -> Unit,
    onSave: () -> Unit,
    onRefresh: () -> Unit,
    onReplaceToken: () -> Unit,
) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(horizontal = 20.dp)
            .verticalScroll(rememberScrollState()),
    ) {
        Spacer(Modifier.height(12.dp))
        OutlinedTextField(
            value = state.amountText,
            onValueChange = onAmountChange,
            modifier = Modifier.fillMaxWidth(),
            label = { Text("Kwota") },
            suffix = { Text(selectedCurrency(state)) },
            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
            singleLine = true,
        )
        Spacer(Modifier.height(12.dp))
        AccountPicker(
            accounts = state.accounts,
            selectedId = state.selectedAccountId,
            onSelected = onAccountSelected,
        )
        Spacer(Modifier.height(12.dp))
        CategoryPicker(
            categories = state.categories,
            selectedId = state.selectedCategoryId,
            onSelected = onCategorySelected,
        )
        Spacer(Modifier.height(12.dp))
        OutlinedTextField(
            value = state.counterParty,
            onValueChange = onCounterPartyChange,
            modifier = Modifier.fillMaxWidth(),
            label = { Text("Sklep / odbiorca (opcjonalnie)") },
            singleLine = true,
        )
        Spacer(Modifier.height(12.dp))
        OutlinedTextField(
            value = state.note,
            onValueChange = onNoteChange,
            modifier = Modifier.fillMaxWidth(),
            label = { Text("Notatka (opcjonalnie)") },
            minLines = 2,
            maxLines = 4,
        )
        state.message?.let {
            Spacer(Modifier.height(12.dp))
            Text(
                text = it,
                color = if (state.saved) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.error,
            )
        }
        Spacer(Modifier.height(20.dp))
        Button(
            onClick = onSave,
            enabled = !state.isBusy && state.accounts.isNotEmpty() && state.categories.isNotEmpty(),
            modifier = Modifier.fillMaxWidth(),
        ) { Text("Zapisz wydatek") }
        Spacer(Modifier.height(8.dp))
        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
            TextButton(onClick = onRefresh, enabled = !state.isBusy) { Text("Odśwież listy") }
            TextButton(onClick = onReplaceToken, enabled = !state.isBusy) { Text("Zmień token") }
        }
        Spacer(Modifier.height(24.dp))
    }
}

@Composable
private fun AccountPicker(
    accounts: List<WalletAccount>,
    selectedId: String?,
    onSelected: (String) -> Unit,
) {
    var expanded by remember { mutableStateOf(false) }
    val selected = accounts.firstOrNull { it.id == selectedId }
    Column {
        Text("Konto", style = MaterialTheme.typography.labelMedium)
        Box {
            OutlinedButton(onClick = { expanded = true }, modifier = Modifier.fillMaxWidth()) {
                Text(selected?.let { "${it.name} · ${it.currencyCode}" } ?: "Wybierz konto")
            }
            DropdownMenu(expanded = expanded, onDismissRequest = { expanded = false }) {
                accounts.forEach { account ->
                    DropdownMenuItem(
                        text = { Text("${account.name} · ${account.currencyCode}") },
                        onClick = {
                            onSelected(account.id)
                            expanded = false
                        },
                    )
                }
            }
        }
    }
}

@Composable
private fun CategoryPicker(
    categories: List<WalletCategory>,
    selectedId: String?,
    onSelected: (String) -> Unit,
) {
    var expanded by remember { mutableStateOf(false) }
    val selected = categories.firstOrNull { it.id == selectedId }
    Column {
        Text("Kategoria", style = MaterialTheme.typography.labelMedium)
        Box {
            OutlinedButton(onClick = { expanded = true }, modifier = Modifier.fillMaxWidth()) {
                Text(selected?.displayName() ?: "Wybierz kategorię")
            }
            DropdownMenu(expanded = expanded, onDismissRequest = { expanded = false }) {
                categories.forEach { category ->
                    DropdownMenuItem(
                        text = { Text(category.displayName()) },
                        onClick = {
                            onSelected(category.id)
                            expanded = false
                        },
                    )
                }
            }
        }
    }
}

private fun WalletCategory.displayName(): String =
    if (groupName.isBlank() || groupName == name) name else "$groupName · $name"

private fun selectedCurrency(state: MainUiState): String =
    state.accounts.firstOrNull { it.id == state.selectedAccountId }?.currencyCode ?: "PLN"
