package pl.polimorph.walletquickadd.data

import org.json.JSONArray
import org.json.JSONObject
import pl.polimorph.walletquickadd.model.ApiResult
import pl.polimorph.walletquickadd.model.ExpenseDraft
import pl.polimorph.walletquickadd.model.WalletAccount
import pl.polimorph.walletquickadd.model.WalletCategory
import pl.polimorph.walletquickadd.model.WalletConfiguration
import java.io.IOException
import java.net.HttpURLConnection
import java.net.URL

class WalletApiClient {
    fun loadConfiguration(token: String): ApiResult<WalletConfiguration> {
        val accountsResult = get("/v1/api/accounts?limit=200&archived=false", token)
        if (accountsResult !is ApiResult.Success) return accountsResult
        val categoriesResult = get("/v1/api/categories?limit=200&archived=false", token)
        if (categoriesResult !is ApiResult.Success) return categoriesResult

        return runCatching {
            val accountsJson = JSONObject(accountsResult.value).getJSONArray("accounts")
            val accounts = buildList {
                for (index in 0 until accountsJson.length()) {
                    val item = accountsJson.getJSONObject(index)
                    add(
                        WalletAccount(
                            id = item.getString("id"),
                            name = item.getString("name"),
                            currencyCode = item.optString("currencyCode", "PLN"),
                            isBankSync = item.optBoolean("isBankSync", false),
                        )
                    )
                }
            }.sortedBy { it.name.lowercase() }

            val categoriesJson = JSONObject(categoriesResult.value).getJSONArray("categories")
            val categories = buildList {
                for (index in 0 until categoriesJson.length()) {
                    val item = categoriesJson.getJSONObject(index)
                    if (!item.optBoolean("enabled", true)) continue
                    add(
                        WalletCategory(
                            id = item.getString("id"),
                            name = item.optString("name").ifBlank { item.optString("parentName", "Bez nazwy") },
                            groupName = item.optJSONObject("group")?.optString("name").orEmpty(),
                        )
                    )
                }
            }.sortedWith(compareBy({ it.groupName.lowercase() }, { it.name.lowercase() }))

            WalletConfiguration(accounts, categories)
        }.fold(
            onSuccess = { ApiResult.Success(it) },
            onFailure = { ApiResult.Failure("Nie udało się odczytać odpowiedzi Wallet: ${it.message}") },
        )
    }

    fun createExpense(token: String, draft: ExpenseDraft): ApiResult<String> {
        val record = JSONObject()
            .put("accountId", draft.accountId)
            .put("amount", JSONObject().put("value", -kotlin.math.abs(draft.amount)))
            .put("categoryId", draft.categoryId)
            .put("recordDate", draft.recordDateIso)
        if (draft.counterParty.isNotBlank()) record.put("counterParty", draft.counterParty.take(255))
        if (draft.note.isNotBlank()) record.put("note", draft.note.take(255))

        val response = request(
            path = "/v1/api/records?returnData=false",
            token = token,
            method = "POST",
            body = JSONArray().put(record).toString(),
        )
        if (response !is ApiResult.Success) return response

        return runCatching {
            val result = JSONObject(response.value).getJSONArray("results").getJSONObject(0)
            if (!result.optBoolean("success")) {
                throw IOException(result.optString("error", "Wallet odrzucił rekord"))
            }
            result.optString("id", "utworzono")
        }.fold(
            onSuccess = { ApiResult.Success(it) },
            onFailure = { ApiResult.Failure(it.message ?: "Wallet odrzucił rekord") },
        )
    }

    private fun get(path: String, token: String): ApiResult<String> =
        request(path, token, "GET", null)

    private fun request(path: String, token: String, method: String, body: String?): ApiResult<String> {
        val connection = (URL(BASE_URL + path).openConnection() as HttpURLConnection)
        return try {
            connection.requestMethod = method
            connection.connectTimeout = 10_000
            connection.readTimeout = 15_000
            connection.setRequestProperty("Accept", "application/json")
            connection.setRequestProperty("Authorization", "Bearer ${token.trim()}")
            if (body != null) {
                connection.doOutput = true
                connection.setRequestProperty("Content-Type", "application/json; charset=utf-8")
                connection.outputStream.bufferedWriter(Charsets.UTF_8).use { it.write(body) }
            }

            val code = connection.responseCode
            val stream = if (code in 200..299) connection.inputStream else connection.errorStream
            val responseBody = stream?.bufferedReader()?.use { it.readText() }.orEmpty()
            when (code) {
                in 200..299 -> ApiResult.Success(responseBody)
                401 -> ApiResult.Failure("Token jest nieprawidłowy albo wygasł.")
                403 -> ApiResult.Failure("To nie jest token Wallet albo nie ma wymaganych uprawnień.")
                409 -> ApiResult.Failure("Wallet wykonuje pierwszą synchronizację. Spróbuj ponownie za chwilę.")
                429 -> ApiResult.Failure(
                    "Przekroczono limit API.",
                    connection.getHeaderField("Retry-After")?.toIntOrNull(),
                )
                else -> ApiResult.Failure(extractError(responseBody, code))
            }
        } catch (exception: IOException) {
            ApiResult.Failure("Brak połączenia z Wallet: ${exception.localizedMessage ?: "błąd sieci"}")
        } finally {
            connection.disconnect()
        }
    }

    private fun extractError(body: String, code: Int): String = runCatching {
        JSONObject(body).optString("error").ifBlank { "Błąd API HTTP $code" }
    }.getOrDefault("Błąd API HTTP $code")

    private companion object {
        const val BASE_URL = "https://rest.budgetbakers.com/wallet"
    }
}
