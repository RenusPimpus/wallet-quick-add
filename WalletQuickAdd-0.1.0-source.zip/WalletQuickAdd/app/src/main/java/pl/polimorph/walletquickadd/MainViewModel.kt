package pl.polimorph.walletquickadd

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import pl.polimorph.walletquickadd.data.UserPreferences
import pl.polimorph.walletquickadd.data.WalletApiClient
import pl.polimorph.walletquickadd.model.ApiResult
import pl.polimorph.walletquickadd.model.ExpenseDraft
import pl.polimorph.walletquickadd.model.WalletAccount
import pl.polimorph.walletquickadd.model.WalletCategory
import pl.polimorph.walletquickadd.security.SecureTokenStore
import pl.polimorph.walletquickadd.util.AmountParser
import java.time.Instant

data class MainUiState(
    val hasToken: Boolean = false,
    val tokenInput: String = "",
    val accounts: List<WalletAccount> = emptyList(),
    val categories: List<WalletCategory> = emptyList(),
    val selectedAccountId: String? = null,
    val selectedCategoryId: String? = null,
    val amountText: String = "",
    val counterParty: String = "",
    val note: String = "",
    val isBusy: Boolean = false,
    val message: String? = null,
    val saved: Boolean = false,
)

class MainViewModel(application: Application) : AndroidViewModel(application) {
    private val tokenStore = SecureTokenStore(application)
    private val preferences = UserPreferences(application)
    private val api = WalletApiClient()

    private val _state = MutableStateFlow(
        MainUiState(
            hasToken = tokenStore.read() != null,
            selectedAccountId = preferences.selectedAccountId,
            selectedCategoryId = preferences.selectedCategoryId,
        )
    )
    val state: StateFlow<MainUiState> = _state.asStateFlow()

    init {
        if (_state.value.hasToken) refreshConfiguration()
    }

    fun acceptSharedText(text: String?) {
        if (text.isNullOrBlank()) return
        val parsed = AmountParser.parseFirst(text)
        _state.update {
            it.copy(
                amountText = parsed?.stripTrailingZeros()?.toPlainString()?.replace('.', ',') ?: it.amountText,
                note = if (text.length <= 255 && parsed == null) text else it.note,
                message = if (parsed == null) "Nie rozpoznałem kwoty — wpisz ją ręcznie." else null,
                saved = false,
            )
        }
    }

    fun updateToken(value: String) = _state.update { it.copy(tokenInput = value, message = null) }
    fun updateAmount(value: String) = _state.update { it.copy(amountText = value, message = null, saved = false) }
    fun updateCounterParty(value: String) = _state.update { it.copy(counterParty = value, saved = false) }
    fun updateNote(value: String) = _state.update { it.copy(note = value, saved = false) }

    fun selectAccount(id: String) {
        preferences.selectedAccountId = id
        _state.update { it.copy(selectedAccountId = id) }
    }

    fun selectCategory(id: String) {
        preferences.selectedCategoryId = id
        _state.update { it.copy(selectedCategoryId = id) }
    }

    fun saveTokenAndConnect() {
        val token = _state.value.tokenInput.trim()
        if (token.isBlank()) {
            _state.update { it.copy(message = "Wklej token API.") }
            return
        }
        tokenStore.save(token)
        _state.update { it.copy(hasToken = true, tokenInput = "") }
        refreshConfiguration()
    }

    fun replaceToken() {
        tokenStore.clear()
        _state.update {
            it.copy(hasToken = false, accounts = emptyList(), categories = emptyList(), message = null)
        }
    }

    fun refreshConfiguration() {
        val token = tokenStore.read() ?: return
        viewModelScope.launch(Dispatchers.IO) {
            _state.update { it.copy(isBusy = true, message = null) }
            when (val result = api.loadConfiguration(token)) {
                is ApiResult.Success -> {
                    val accountId = preferences.selectedAccountId
                        ?.takeIf { id -> result.value.accounts.any { it.id == id } }
                    val categoryId = preferences.selectedCategoryId
                        ?.takeIf { id -> result.value.categories.any { it.id == id } }
                    accountId?.let { preferences.selectedAccountId = it }
                    categoryId?.let { preferences.selectedCategoryId = it }
                    _state.update {
                        it.copy(
                            accounts = result.value.accounts,
                            categories = result.value.categories,
                            selectedAccountId = accountId,
                            selectedCategoryId = categoryId,
                            isBusy = false,
                            message = if (result.value.accounts.isEmpty()) "Wallet nie zwrócił aktywnych kont." else null,
                        )
                    }
                }
                is ApiResult.Failure -> _state.update {
                    it.copy(isBusy = false, message = result.message)
                }
            }
        }
    }

    fun saveExpense() {
        val current = _state.value
        val amount = AmountParser.normalize(current.amountText)?.toDoubleOrNull()
        val accountId = current.selectedAccountId
        val categoryId = current.selectedCategoryId
        when {
            amount == null || amount <= 0.0 -> {
                _state.update { it.copy(message = "Podaj poprawną kwotę większą od zera.") }
                return
            }
            accountId == null -> {
                _state.update { it.copy(message = "Wybierz konto.") }
                return
            }
            categoryId == null -> {
                _state.update { it.copy(message = "Wybierz kategorię.") }
                return
            }
        }
        val token = tokenStore.read() ?: return
        viewModelScope.launch(Dispatchers.IO) {
            _state.update { it.copy(isBusy = true, message = null, saved = false) }
            val result = api.createExpense(
                token,
                ExpenseDraft(
                    accountId = accountId,
                    categoryId = categoryId,
                    amount = amount,
                    counterParty = current.counterParty.trim(),
                    note = current.note.trim(),
                    recordDateIso = Instant.now().toString(),
                )
            )
            when (result) {
                is ApiResult.Success -> _state.update {
                    it.copy(
                        isBusy = false,
                        saved = true,
                        message = "Wydatek zapisany.",
                        amountText = "",
                        counterParty = "",
                        note = "",
                    )
                }
                is ApiResult.Failure -> _state.update {
                    it.copy(isBusy = false, message = result.message)
                }
            }
        }
    }
}
