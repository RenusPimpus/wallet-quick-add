package pl.polimorph.walletquickadd.util

import java.math.BigDecimal

object AmountParser {
    private val currencyNearNumber = Regex(
        pattern = "(?i)(?:PLN|zł|EUR|€|USD|\\$)?\\s*(-?\\d{1,3}(?:[ .\\u00A0]\\d{3})*(?:[,.]\\d{1,2})|-?\\d+(?:[,.]\\d{1,2})?)\\s*(?:PLN|zł|EUR|€|USD|\\$)?"
    )

    fun parseFirst(text: String): BigDecimal? {
        val raw = currencyNearNumber.find(text)?.groupValues?.getOrNull(1) ?: return null
        return normalize(raw)?.toBigDecimalOrNull()?.abs()
    }

    fun normalize(input: String): String? {
        var value = input.trim().replace("\u00A0", "").replace(" ", "")
        if (value.isBlank()) return null

        val comma = value.lastIndexOf(',')
        val dot = value.lastIndexOf('.')
        value = when {
            comma >= 0 && dot >= 0 && comma > dot -> value.replace(".", "").replace(',', '.')
            comma >= 0 && dot >= 0 -> value.replace(",", "")
            comma >= 0 -> value.replace(',', '.')
            else -> value
        }
        return value.takeIf { it.matches(Regex("-?\\d+(?:\\.\\d{1,2})?")) }
    }
}
