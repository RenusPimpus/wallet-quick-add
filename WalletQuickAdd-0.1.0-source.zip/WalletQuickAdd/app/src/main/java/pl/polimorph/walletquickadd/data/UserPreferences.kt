package pl.polimorph.walletquickadd.data

import android.content.Context

class UserPreferences(context: Context) {
    private val preferences = context.getSharedPreferences("user_preferences", Context.MODE_PRIVATE)

    var selectedAccountId: String?
        get() = preferences.getString("account_id", null)
        set(value) = preferences.edit().putString("account_id", value).apply()

    var selectedCategoryId: String?
        get() = preferences.getString("category_id", null)
        set(value) = preferences.edit().putString("category_id", value).apply()
}
