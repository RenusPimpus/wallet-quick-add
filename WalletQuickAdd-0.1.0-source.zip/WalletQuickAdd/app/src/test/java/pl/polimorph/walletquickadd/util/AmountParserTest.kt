package pl.polimorph.walletquickadd.util

import org.junit.Assert.assertEquals
import org.junit.Assert.assertNull
import org.junit.Test
import java.math.BigDecimal

class AmountParserTest {
    @Test fun parsesPolishDecimalComma() {
        assertEquals(BigDecimal("12.50"), AmountParser.parseFirst("12,50 zł"))
    }

    @Test fun parsesThousandsWithSpaces() {
        assertEquals(BigDecimal("1234.56"), AmountParser.parseFirst("Razem: 1 234,56 PLN"))
    }

    @Test fun parsesDotDecimal() {
        assertEquals(BigDecimal("8.99"), AmountParser.parseFirst("USD 8.99"))
    }

    @Test fun expenseIsAlwaysReturnedAsAbsoluteValue() {
        assertEquals(BigDecimal("42.00"), AmountParser.parseFirst("-42,00"))
    }

    @Test fun rejectsTextWithoutAmount() {
        assertNull(AmountParser.parseFirst("paragon ze sklepu"))
    }
}
